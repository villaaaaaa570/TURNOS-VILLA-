-- Requiere pg_cron, pg_net y supabase_vault habilitados. Guardá en Vault:
-- project_url = https://TU-PROYECTO.supabase.co
-- reminder_cron_secret = el mismo valor que REMINDER_CRON_SECRET de la Edge Function
select cron.schedule('shinezone-send-reminders-every-5-minutes','*/5 * * * *', $$
  select net.http_post(
    url := (select decrypted_secret from vault.decrypted_secrets where name='project_url') || '/functions/v1/send-reminders',
    headers := jsonb_build_object('Content-Type','application/json','Authorization','Bearer ' || (select decrypted_secret from vault.decrypted_secrets where name='reminder_cron_secret')),
    body := '{}'::jsonb
  );
$$);
