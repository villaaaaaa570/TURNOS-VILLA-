create extension if not exists pgcrypto;
create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(), customer_name text not null, customer_phone text not null,
  vehicle text, service text, starts_at timestamptz not null,
  status text not null default 'scheduled' check (status in ('scheduled','cancelled','completed')),
  reminder_sent_at timestamptz, reminder_error text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists bookings_starts_at_idx on public.bookings(starts_at);
create index if not exists bookings_reminder_idx on public.bookings(starts_at, reminder_sent_at) where status='scheduled';
alter table public.bookings enable row level security;
create policy "Authenticated users can manage bookings" on public.bookings for all to authenticated using (true) with check (true);
