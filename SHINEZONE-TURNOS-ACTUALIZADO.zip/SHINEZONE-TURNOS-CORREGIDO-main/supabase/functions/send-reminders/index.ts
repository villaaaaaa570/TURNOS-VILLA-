import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const expected = Deno.env.get('REMINDER_CRON_SECRET');
  if (!expected || (req.headers.get('authorization') || '') !== `Bearer ${expected}`) return new Response('Unauthorized', { status: 401, headers: corsHeaders });
  const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const token = Deno.env.get('WHATSAPP_ACCESS_TOKEN'), phoneNumberId = Deno.env.get('WHATSAPP_PHONE_NUMBER_ID');
  const templateName = Deno.env.get('WHATSAPP_TEMPLATE_NAME') || 'recordatorio_turno_shinezone';
  const languageCode = Deno.env.get('WHATSAPP_TEMPLATE_LANGUAGE') || 'es_AR';
  if (!token || !phoneNumberId) return new Response('Missing WhatsApp secrets', { status: 500, headers: corsHeaders });
  const now = Date.now(), from = new Date(now + 23*3600000 + 55*60000).toISOString(), to = new Date(now + 24*3600000 + 5*60000).toISOString();
  const { data: rows, error } = await db.from('bookings').select('*').eq('status','scheduled').is('reminder_sent_at',null).gte('starts_at',from).lte('starts_at',to).limit(100);
  if (error) return new Response(JSON.stringify({error:error.message}), {status:500,headers:{...corsHeaders,'Content-Type':'application/json'}});
  const results = [];
  for (const b of rows || []) {
    const phone = String(b.customer_phone).replace(/[^0-9]/g,''); const when = new Date(b.starts_at);
    const dateText = new Intl.DateTimeFormat('es-AR',{timeZone:'America/Argentina/Buenos_Aires',weekday:'long',day:'2-digit',month:'2-digit'}).format(when);
    const timeText = new Intl.DateTimeFormat('es-AR',{timeZone:'America/Argentina/Buenos_Aires',hour:'2-digit',minute:'2-digit',hour12:false}).format(when);
    const payload = {messaging_product:'whatsapp',to:phone,type:'template',template:{name:templateName,language:{code:languageCode},components:[{type:'body',parameters:[{type:'text',text:b.customer_name},{type:'text',text:dateText},{type:'text',text:timeText},{type:'text',text:b.service || 'Servicio de detailing'}]}]}};
    try {
      const response = await fetch(`https://graph.facebook.com/v22.0/${phoneNumberId}/messages`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify(payload)}); const body = await response.json();
      if (!response.ok) { await db.from('bookings').update({reminder_error:JSON.stringify(body).slice(0,1000)}).eq('id',b.id); results.push({id:b.id,sent:false,error:body.error?.message||'WhatsApp API error'}); continue; }
      await db.from('bookings').update({reminder_sent_at:new Date().toISOString(),reminder_error:null}).eq('id',b.id); results.push({id:b.id,sent:true});
    } catch(e) { await db.from('bookings').update({reminder_error:String(e).slice(0,1000)}).eq('id',b.id); results.push({id:b.id,sent:false,error:String(e)}); }
  }
  return new Response(JSON.stringify({checked:rows?.length||0,results}),{headers:{...corsHeaders,'Content-Type':'application/json'}});
});
