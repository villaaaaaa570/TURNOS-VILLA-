# ShineZone Turnos — base de datos y recordatorios

La interfaz ahora admite fecha real, horario, nombre, teléfono, vehículo y servicio. Puede conectarse a Supabase; la Edge Function envía plantillas de WhatsApp a turnos aproximadamente 24 horas antes. **No queda activa hasta configurar credenciales, autenticación y la programación.**

## 1. Base de datos
1. Creá un proyecto Supabase.
2. Ejecutá `supabase/schema.sql` desde SQL Editor.
3. Copiá Project URL y clave anon/publishable desde Project Settings → API.
4. Reemplazá los valores de `config.js`. Nunca pegues allí la `service_role key`.

La tabla usa Row Level Security y permite gestionar turnos a usuarios autenticados. Antes de usarla con datos reales, hay que agregar inicio de sesión en la app; no abras la tabla a usuarios anónimos.

## 2. WhatsApp Business Platform
Necesitás configurar una cuenta de Meta/WhatsApp Business Platform, un número habilitado, token de acceso y el Phone Number ID. Creá y conseguí aprobación para una plantilla de utilidad con cuatro variables de cuerpo, por ejemplo:

`Hola {{1}}, te recordamos tu turno en ShineZone para el {{2}} a las {{3}}. Servicio: {{4}}. Si necesitás cambiarlo, respondé a este mensaje.`

El nombre e idioma de plantilla deben coincidir con `WHATSAPP_TEMPLATE_NAME` y `WHATSAPP_TEMPLATE_LANGUAGE`. Respetá las políticas vigentes de Meta y obtené el consentimiento del cliente para recibir mensajes.

## 3. Desplegar la función
Con Supabase CLI instalada, desde esta carpeta:

```bash
supabase login
supabase link --project-ref TU_PROJECT_REF
supabase functions deploy send-reminders
supabase secrets set REMINDER_CRON_SECRET="UN_SECRETO_LARGO_Y_ALEATORIO" WHATSAPP_ACCESS_TOKEN="TOKEN_DE_META" WHATSAPP_PHONE_NUMBER_ID="ID_DEL_NUMERO" WHATSAPP_TEMPLATE_NAME="recordatorio_turno_shinezone" WHATSAPP_TEMPLATE_LANGUAGE="es_AR"
```

Las Edge Functions suelen recibir `SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY` automáticamente; confirmalo en la configuración del proyecto. Nunca compartas estos secretos ni los subas a GitHub.

## 4. Programar cada cinco minutos
Habilitá `pg_cron`, `pg_net` y `supabase_vault` si están disponibles en tu proyecto. En Vault creá los secretos `project_url` y `reminder_cron_secret`. El segundo debe coincidir con `REMINDER_CRON_SECRET`. Después ejecutá `supabase/schedule-reminders.sql`.

La función busca turnos dentro de una ventana de 10 minutos centrada en las 24 horas previas. Marca el recordatorio como enviado cuando Meta acepta la solicitud; revisá los logs y `reminder_error` si falla.

## 5. Horarios y publicación
Editá `schedule` al principio de `index.html`. Los días usan la numeración JavaScript: 0 domingo, 1 lunes, 2 martes, 3 miércoles, 4 jueves, 5 viernes, 6 sábado. Subí los archivos a GitHub Pages. Sin configurar Supabase, la app funciona en modo local de prueba, pero no sincroniza dispositivos ni manda recordatorios.
