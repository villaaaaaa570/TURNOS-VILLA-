// Configuración pública del frontend. Completá estos valores desde Supabase > Project Settings > API.
// La anon/publishable key es pública; NUNCA pongas la service_role key acá.
window.SHINEZONE_CONFIG = {
  supabaseUrl: "PEGAR_URL_DEL_PROYECTO_SUPABASE",
  supabaseAnonKey: "PEGAR_CLAVE_ANON_PUBLICA_DE_SUPABASE"
};
